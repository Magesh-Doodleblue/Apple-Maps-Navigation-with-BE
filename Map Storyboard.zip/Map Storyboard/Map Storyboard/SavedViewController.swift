//
//  SavedViewController.swift
//  Map Storyboard
//
//  Created by DB-MM-011 on 20/06/23.
//
import UIKit
import Foundation

class SavedViewController : UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }    
    
}
